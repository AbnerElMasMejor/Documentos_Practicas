
const express = require('express');

const app = express();
app.use(express.json());

let usuarios = [];
let siguienteId = 1;

// GET: consultar todos los usuarios
app.get('/usuarios', (req, res) => {
    res.json(usuarios);
});

// GET: consultar un usuario por su ID
app.get('/usuarios/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const usuario = usuarios.find(u => u.id === id);

    if (!usuario) {
        return res.status(404).json({
            mensaje: 'Usuario no encontrado'
        });
    }

    res.json(usuario);
});

// POST: registrar un usuario
app.post('/usuarios', (req, res) => {
    const { nombre, correo } = req.body;

    if (!nombre || !correo) {
        return res.status(400).json({
            mensaje: 'El nombre y el correo son obligatorios'
        });
    }

    const nuevoUsuario = {
        id: siguienteId++,
        nombre: nombre,
        correo: correo
    };

    usuarios.push(nuevoUsuario);

    res.status(201).json(nuevoUsuario);
});

// PUT: actualizar un usuario
app.put('/usuarios/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const usuario = usuarios.find(u => u.id === id);

    if (!usuario) {
        return res.status(404).json({
            mensaje: 'Usuario no encontrado'
        });
    }

    const { nombre, correo } = req.body;

    if (!nombre || !correo) {
        return res.status(400).json({
            mensaje: 'El nombre y el correo son obligatorios'
        });
    }

    usuario.nombre = nombre;
    usuario.correo = correo;

    res.json({
        mensaje: 'Usuario actualizado',
        usuario: usuario
    });
});

// DELETE: eliminar un usuario
app.delete('/usuarios/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const indice = usuarios.findIndex(u => u.id === id);

    if (indice === -1) {
        return res.status(404).json({
            mensaje: 'Usuario no encontrado'
        });
    }

    const usuarioEliminado = usuarios.splice(indice, 1);

    res.json({
        mensaje: 'Usuario eliminado',
        usuario: usuarioEliminado[0]
    });
});

// Iniciar el servidor
app.listen(3000, () => {
    console.log('API REST funcionando en http://localhost:3000');
});
